#ifndef SlimList_Deserialize_H
#define SlimList_Deserialize_H

SlimList* SlimList_Deserialize(char const *);

#endif
