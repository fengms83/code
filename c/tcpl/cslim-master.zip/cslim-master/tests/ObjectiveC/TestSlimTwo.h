#import <Foundation/Foundation.h>

@interface TestSlimTwo : NSObject {
    
}

@end
