#include "Fixtures.h"

SLIM_FIXTURES
	SLIM_FIXTURE(Division)
	SLIM_FIXTURE(Count)
	SLIM_FIXTURE(EmployeePayRecordsRow)
	SLIM_FIXTURE(ExceptionsExample)
  SLIM_FIXTURE(Multiplication)
SLIM_END

